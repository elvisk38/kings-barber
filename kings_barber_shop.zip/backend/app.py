
from flask import Flask, render_template, request, redirect, url_for
import sqlite3

app = Flask(__name__)

# Database connection
def get_db_connection():
    conn = sqlite3.connect('backend/shop.db')
    conn.row_factory = sqlite3.Row
    return conn

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/services')
def services():
    services_list = [
        {"name": "Haircut", "price": "$20"},
        {"name": "Beard Trim", "price": "$15"},
        {"name": "Shaving", "price": "$10"},
        {"name": "Hair Color", "price": "$30"},
        {"name": "Hot Towel Shave", "price": "$25"},
    ]
    return render_template('services.html', services=services_list)

@app.route('/booking', methods=['GET', 'POST'])
def booking():
    if request.method == 'POST':
        name = request.form['name']
        phone = request.form['phone']
        service = request.form['service']
        time = request.form['time']

        conn = get_db_connection()
        conn.execute(
            'INSERT INTO bookings (name, phone, service, time) VALUES (?, ?, ?, ?)',
            (name, phone, service, time)
        )
        conn.commit()
        conn.close()
        return render_template('success.html', name=name, service=service, time=time)
    return render_template('booking.html')

@app.route('/contact')
def contact():
    return render_template('contact.html')

if __name__ == '__main__':
    app.run(debug=True)

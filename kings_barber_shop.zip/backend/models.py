
import sqlite3

# Create SQLite database
connection = sqlite3.connect('backend/shop.db')
cursor = connection.cursor()

# Create table for bookings
cursor.execute('''
CREATE TABLE IF NOT EXISTS bookings (
    id INTEGER PRIMARY KEY,
    name TEXT NOT NULL,
    phone TEXT NOT NULL,
    service TEXT NOT NULL,
    time TEXT NOT NULL
)
''')

connection.commit()
connection.close()
